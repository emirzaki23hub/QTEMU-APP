import { createStore } from "redux";

const initialState = {
  posts: [
    {
      id: "e1",
      date: "27 November 2018",
      content: "#40 JakartaJS April Meetup with kumparan",
      view: "140 went",
    },
    {
      id: "e2",
      date: "27 November 2019",
      content: "#41 JakartaJS April Meetup with kumparan",
      view: "141 went",
    },
    {
      id: "e3",
      date: "27 November 2020",
      content: "#42 JakartaJS April Meetup with kumparan",
      view: "142 went",
    },
    
  ],
  datas: [
    {
      title: "Hacktive Meetup",
      members:"Members: 1078",
      location:"Location: Jakarta Indonesia",
      organizers:"Organizer: Adhy",
  }
  ],
};

const reducer= (state = initialState, action) => { 
  return state;
}

export const store = createStore(reducer);
