import React from 'react'

function About() {
    return (
        <div className="container">
     <div className="about" style={{textAlign:'left'}}>
    <h3 style={{paddingTop:'15px'}}>About Meetup</h3>
    <p>Come and Meet other developers interisted in the Javascript and its library in the greater jakarta area</p>
    <p>Twitter:@JakartaJS and we use the hashtag #jakartajs</p>
    </div>
        </div>
    )
}

export default About
