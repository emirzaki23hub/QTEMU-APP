import React from "react";
import * as ReactBoostrap from "react-bootstrap";

function Explore() {
  return (
    <div className="container" style={{marginTop:'20px', minHeight:'100vh'}} >
      <h1 style={{textAlign:'left'}}>Explore</h1>
      <hr/>
      <ReactBoostrap.Form className="d-flex" >
        <ReactBoostrap.FormControl
          type="search"
          placeholder="Search"
          className="me-2"
          aria-label="Search"
        />
        <ReactBoostrap.Button variant="outline-success">Search</ReactBoostrap.Button>
      </ReactBoostrap.Form>
    </div>
  );
}

export default Explore;
