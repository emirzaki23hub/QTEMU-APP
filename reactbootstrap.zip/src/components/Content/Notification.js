import React, { Component } from "react";
import * as ReactBoostrap from "react-bootstrap";
import {connect} from 'react-redux'

// import { useSelector } from "react-redux";

class Notification extends Component   {
render () {
  const {datas} = this.props; 
  const dataList = datas.map((data) => { 
  return (
    <div className="container" style={{ paddingTop: "20px" }}>
      <ReactBoostrap.Card>
        <ReactBoostrap.Card.Body>
          <ReactBoostrap.Card.Img
            className="img"
            src="https://thumbs.dreamstime.com/b/man-icon-person-vector-worker-162495520.jpg"
          />
          <ReactBoostrap.Card.Title style={{ textAlign: "left" }}>
            {data.title}
          </ReactBoostrap.Card.Title>
          <ReactBoostrap.Card.Text style={{ textAlign: "left" }}>
            <p>
              {" "}
              {data.location} <br /> {data.members} <br /> {data.organizers}{" "}
            </p>
            <ReactBoostrap.Button>Join Us</ReactBoostrap.Button>
          </ReactBoostrap.Card.Text>
        </ReactBoostrap.Card.Body>
      </ReactBoostrap.Card>
    </div>
  );
})
return(
  <div>
 {dataList} 
</div>
)
}
}

const mapStateToProps = (state) => {
  return {
    datas: state.datas,
  };
};

export default connect (mapStateToProps) (Notification);
