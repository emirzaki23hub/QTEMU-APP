import React, { useState } from "react";
import * as ReactBoostrap from "react-bootstrap";
import "./Login.css";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="container">
      <div className="containera">
        <h2>LOGIN</h2>
        <ReactBoostrap.Form className="emaila">
          <ReactBoostrap.Form.Group className="mb-3" controlId="formBasicEmail">
            <ReactBoostrap.Form.Label>Email address</ReactBoostrap.Form.Label>
            <ReactBoostrap.Form.Control
              type="email"
              value={email}
              placeholder="Enter email"
              onChange={(e) => setEmail(e.target.value)}
            />
            <ReactBoostrap.Form.Text className="text-muted"></ReactBoostrap.Form.Text>
          </ReactBoostrap.Form.Group>

          <ReactBoostrap.Form.Group
            className="mb-3"
            controlId="formBasicPassword"
          >
            <ReactBoostrap.Form.Label>Password</ReactBoostrap.Form.Label>
            <ReactBoostrap.Form.Control
              type="password"
              value={password}
              placeholder="Password"
              onChange={(e) => setPassword(e.target.value)}
            />
          </ReactBoostrap.Form.Group>
          <ReactBoostrap.Button variant="primary" type="submit">
            Submit
          </ReactBoostrap.Button>
        </ReactBoostrap.Form>
      </div>
    </div>
  );
}

export default Login;
