import React from "react";
import { Link } from "react-router-dom";
import * as ReactBoostrap from "react-bootstrap";
import "./Member.css";

function Member(props) {
  const organizers = "Adhy Wirathna";
  const members = "4 others.";
  return (
    <div className="container" style={{ paddingTop: "15px" }}>
      <p style={{ float: "right" }}>
        <Link to="./login">See All</Link> 
      </p>
      <h3 style={{ textAlign: "left" }}>Member</h3>
      <ReactBoostrap.Card>
        <ReactBoostrap.Card.Body>
          <ReactBoostrap.Card.Img
            className="img"
            src="https://thumbs.dreamstime.com/b/man-icon-person-vector-worker-162495520.jpg"
          />
          <ReactBoostrap.Card.Text className="body">
            <h5> Organizers</h5>
            <p style={{ float: "left", paddingRight: "10px" }}>{organizers}</p>
            <p style={{ float: "right", paddingLeft: "15px" }}> {members} </p>
          </ReactBoostrap.Card.Text>
        </ReactBoostrap.Card.Body>
      </ReactBoostrap.Card>
    </div>
  );
}

export default Member;
