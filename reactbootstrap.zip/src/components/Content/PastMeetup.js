import React, { Component } from "react";
import * as ReactBoostrap from "react-bootstrap";
import { connect } from "react-redux";

class PastMeetup extends Component {
  render() {
    const { posts } = this.props;
    const postList = posts.map((post) => {
      return (
        <div>
          <ReactBoostrap.Col>
            <ReactBoostrap.Card style={{ width: "420px" }}>
              <ReactBoostrap.Card.Body style={{ textAlign: "left" }}>
                <ReactBoostrap.Card.Title>{post.date}</ReactBoostrap.Card.Title>
                <ReactBoostrap.Card.Text>
                  <div className="card-bodi">
                    <hr />
                    <p>{post.content}</p>
                    <p>{post.view}</p>
                    <ReactBoostrap.Button>View</ReactBoostrap.Button>
                  </div>
                </ReactBoostrap.Card.Text>
              </ReactBoostrap.Card.Body>
            </ReactBoostrap.Card>
          </ReactBoostrap.Col>
        </div>
      );
    });
    return (
      <ReactBoostrap.Row xs={1} md={3}>
        {postList}
      </ReactBoostrap.Row>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    posts: state.posts,
  };
};

export default connect(mapStateToProps)(PastMeetup);
