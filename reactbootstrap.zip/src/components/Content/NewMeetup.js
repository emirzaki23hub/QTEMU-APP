import React from 'react'
import * as ReactBoostrap from "react-bootstrap";

function NewMeetup() {
    return (
        <div style={{textAlign:'left', minHeight:'100vh'}} className="container" >
           <h1 >Create Meeetup</h1>
           <hr/>
           <div>
           <ReactBoostrap.Form   >
      <ReactBoostrap.Row className="mb-3">
        <ReactBoostrap.Form.Group  md="6" controlId="validationCustom03">
          <ReactBoostrap.Form.Label>City</ReactBoostrap.Form.Label>
          <ReactBoostrap.Form.Control type="text" placeholder="City" required />
          <ReactBoostrap.Form.Control.Feedback type="invalid">
            Please provide a valid city.
          </ReactBoostrap.Form.Control.Feedback>
        </ReactBoostrap.Form.Group>
        <ReactBoostrap.Form.Group  md="3" controlId="validationCustom04">
          <ReactBoostrap.Form.Label>State</ReactBoostrap.Form.Label>
          <ReactBoostrap.Form.Control type="text" placeholder="State" required />
          <ReactBoostrap.Form.Control.Feedback type="invalid">
            Please provide a valid state.
          </ReactBoostrap.Form.Control.Feedback>
        </ReactBoostrap.Form.Group>
        <ReactBoostrap.Form.Group md="3" controlId="validationCustom05">
          <ReactBoostrap.Form.Label>Zip</ReactBoostrap.Form.Label>
          <ReactBoostrap.Form.Control type="text" placeholder="Zip" required />
          <ReactBoostrap.Form.Control.Feedback type="invalid">
            Please provide a valid zip.
          </ReactBoostrap.Form.Control.Feedback>
        </ReactBoostrap.Form.Group>
      </ReactBoostrap.Row>
      <ReactBoostrap.Form.Group className="mb-3">
        <ReactBoostrap.Form.Check
          required
          label="Agree to terms and conditions"
          feedback="You must agree before submitting."
          feedbackType="invalid"
        />
      </ReactBoostrap.Form.Group>
      <ReactBoostrap.Button type="submit">Create Meetup</ReactBoostrap.Button>
    </ReactBoostrap.Form>
           </div>
        </div>
    )
}

export default NewMeetup
