import React from "react";
import About from "./About";
import Member from "./Member";
import NextMeetup from "./NextMeetup";
import Notification from "./Notification";
import PastMeetupCard from "./PastMeetupCard";

function Meetup(props) {
  return (
    <div>
      <Notification />
      <NextMeetup
        text="Awesome meetup and event"
        date="25 January 2019"
        text1="Hello, Javascript & Node.js Ninjas!"
      />
      <About />
      <Member />
      <PastMeetupCard />
    </div>
  );
}

export default Meetup;
