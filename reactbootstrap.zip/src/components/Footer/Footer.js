import React from "react";

function Footer() {
  return (
    <div style={{textAlign:'center'}}>
      <hr />
      <h4> Copyright Hacktive8</h4>
    </div>
  );
}

export default Footer;
